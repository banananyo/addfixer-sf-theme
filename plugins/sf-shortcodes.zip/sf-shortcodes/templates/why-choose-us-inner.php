<?php
/*****************************************************************************
*
*	copyright(c) - aonetheme.com - Service Finder Team
*	More Info: http://aonetheme.com/
*	Coder: Service Finder Team
*	Email: contact@aonetheme.com
*
******************************************************************************/
?>
<?php
$html = '<div class="col-md-4">
                          <div class="sf-why-choose w-t-element padding-lr-20">
                                <div class="sf-icon-xl margin-b-20">
                                    <img src="'.esc_url($a['img']).'" width="220" height="200" alt="">
                                </div>
                                <h4 class="sf-tilte margin-b-10">'.esc_html($a['title']).'</h4>
                                <p>'.$content.'</p>
                                
                          </div>
                        </div>';
?>

